 var mobileNumber = context.getVariable("mobileNumber"); 
 var password = context.getVariable("password"); 

var resBody;

if(mobileNumber == "0331234")
{
    resBody = "not verified";
}
else if(mobileNumber == "03312345")
{
     resBody = "not verified";
}
else if(password == "123")
{
     resBody = "not verified";
}
else 
{
     resBody = "verified";
}

context.setVariable("resBody",resBody);