var name = context.getVariable("name"); 
var resBody;

if(name == "Hira" )
{
    resBody = "verified";
}
else if(name == "Aroob" )
{
     resBody = "verified";
}
else 
{
     resBody = "not verified";
}

context.setVariable("resBody",JSON.stringify(resBody));