var name = context.getVariable("name"); 
var password = context.getVariable("password"); 
var resBody;

if(name == "hira" &&  password == "123")
{
    resBody = "verified";
}
else if(name == "aroob" && password == "123" )
{
     resBody = "verified";
}
else 
{
     resBody = "not verified";
}

context.setVariable("resBody",resBody);