  var reqBody = JSON.parse(context.getVariable('request.content'));
  var noOfSum = Object.keys(reqBody.sum).length;
  var total = sum(noOfSum, JSON.parse('{ "sum": [ 1, 2, 3, 4, 5 ] }'));
  
//   if(noOfSum == 0 || noOfSum == null){
//       throw new Error();
//   }
  
  function sum(noOfSum, reqBody) {
    var total = 0;
      for(var i=0; i<noOfSum; i++){
          
        if(typeof reqBody.sum[i] != "number"){
          throw new Error();
        }
          total = total + reqBody.sum[i];
      }
      return total;
  }
  
   context.setVariable("reqBody", reqBody);
   context.setVariable("noOfSum", noOfSum);
   context.setVariable("total", total);