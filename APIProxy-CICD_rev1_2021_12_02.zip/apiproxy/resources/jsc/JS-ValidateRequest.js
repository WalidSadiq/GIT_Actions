var userName = context.getVariable("userName");
var userId = context.getVariable("userId");
var userEmail = context.getVariable("userEmail");
var userPhn = context.getVariable("userPhn");

checkIsMandatory("userName", userName);
checkIsMandatory("userId", userId);
checkIsMandatory("userEmail", userEmail);
checkIsMandatory("userPhn", userPhn);
checkMaxLength("userName", userName, 20);
checkRegx("userId", userId, "AN");
checkRegx("userEmail", userEmail, "Email");
checkRegx("userPhn", userPhn, "N");
checkRegx("userPhn", userPhn, "MobileNo");